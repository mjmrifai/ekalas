﻿You may try "Clink" - bash style autocomplete
Download and unpack files to this folder

https://chrisant996.github.io/clink/

Note! Clink distribution has subfolders.
Unpack all the files (without subfolder) into %ConEmuBaseDir%\clink.
This folder already created by ConEmu installer and contains Readme.txt.

If you install clink in any other folder,
ConEmu will not be able to control clink
loading from ConEmu's settings dialog:

Settings -> Features -> Use clink in prompt
https://conemu.github.io/en/SettingsFeatures.html
